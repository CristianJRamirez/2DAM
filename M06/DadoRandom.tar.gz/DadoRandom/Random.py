
import random
import sys

#print random.randint(1,10)


sys.stdout.write(str(random.randint(1,10)))

