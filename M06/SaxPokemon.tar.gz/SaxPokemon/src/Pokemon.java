/**
 * Created by 45858000w on 26/09/16.
 */
public class Pokemon {

    private String Nombre;
    private String PV;
    private String Ataque1;
    private String Ataque2;
    private String Etapa;
    private String Classe;

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getPV() {
        return PV;
    }

    public void setPV(String PV) {
        this.PV = PV;
    }

    public String getAtaque1() {
        return Ataque1;
    }

    public void setAtaque1(String ataque1) {
        Ataque1 = ataque1;
    }

    public String getAtaque2() {
        return Ataque2;
    }

    public void setAtaque2(String ataque2) {
        Ataque2 = ataque2;
    }

    public String getEtapa() {
        return Etapa;
    }

    public void setEtapa(String etapa) {
        Etapa = etapa;
    }

    public String getClasse() {
        return Classe;
    }

    public void setClasse(String classe) {
        Classe = classe;
    }
}
